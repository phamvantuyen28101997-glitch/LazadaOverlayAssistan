# Lazada Floating Price (mã nguồn Android)

## Có gì trong bản này
- Cửa sổ nổi Android để nhập tên/link sản phẩm, giá mục tiêu và giá hiện tại thủ công.
- So sánh giá do người dùng nhập; khi giá hiện tại thấp hơn hoặc bằng giá mục tiêu và bạn bấm “So sánh giá”, ứng dụng gửi thông báo Android. Thông báo nêu rõ giá thấp hơn mục tiêu hay bằng mục tiêu; nếu trường sản phẩm là URL thì chạm thông báo để mở liên kết. Android 13 trở lên sẽ hỏi quyền thông báo khi mở app lần đầu.
- **Lưu giá mục tiêu riêng cho từng sản phẩm** theo tên/link bạn nhập; danh sách được lưu trên điện thoại, bấm một sản phẩm đã lưu để nạp lại giá mục tiêu, hoặc bấm × để xóa.
- Trang giỏ hàng trong WebView riêng có nút bật/tạm dừng tải lại mỗi 1 giây.
- **Thử nghiệm tự làm mới trong app Lazada gốc** qua Android Accessibility Service: khi bật, dịch vụ gửi thao tác vuốt xuống mỗi giây khi `com.lazada.android` đang ở trước màn hình.

## Bật tính năng tự tải lại trong app Lazada gốc
1. Cài APK do bạn tự build.
2. Mở ứng dụng và bật cửa sổ nổi.
3. Trong cửa sổ nổi, bấm **Bật tự tải lại app Lazada gốc (1 giây)**.
4. Android sẽ mở Cài đặt Trợ năng. Tìm **Lazada Floating Price** và bật dịch vụ; xác nhận cảnh báo hệ thống.
5. Mở app Lazada gốc, vào trang giỏ hàng và đưa trang lên đầu. Dịch vụ sẽ thử vuốt xuống mỗi 1 giây.
6. Để dừng, bấm **Tắt tự tải lại app Lazada gốc** trong cửa sổ nổi hoặc tắt dịch vụ Trợ năng trong Cài đặt.

## Giới hạn quan trọng
- Android không cung cấp API công khai để app này trực tiếp gọi nút refresh bên trong app Lazada gốc. Bản thử nghiệm dùng Accessibility Service để giả lập thao tác kéo xuống.
- Cử chỉ vuốt xuống **không đảm bảo** là làm mới: tùy phiên bản Lazada và vị trí trang, nó có thể chỉ cuộn danh sách hoặc không có tác dụng. Hãy thử trước với chu kỳ 1 giây; nếu gây cuộn ngoài ý muốn, tắt ngay.
- Chạy mỗi giây có thể làm tải trang liên tục, hao pin/dữ liệu hoặc khiến Lazada giới hạn truy cập. Android/OEM cũng có thể hạn chế dịch vụ nền.
- Việc lưu giá mục tiêu theo sản phẩm hiện dựa trên tên/link do người dùng nhập thủ công. Ứng dụng chưa tự phát hiện danh sách sản phẩm trong giỏ hàng Lazada gốc và chưa tự gắn mục tiêu với từng dòng sản phẩm trong giỏ. Cảnh báo giá hiện được kích hoạt khi bạn nhập giá hiện tại và bấm “So sánh giá”; chưa tự đọc giá thật hoặc theo dõi giảm giá tự động trong nền.
- Chưa tự đọc giá thật từ Lazada, chưa đồng bộ giỏ hàng, chưa tự đặt hàng/thanh toán. Giá hiện tại vẫn phải nhập thủ công.
- Chưa biên dịch hoặc kiểm thử APK trong môi trường này; đây là mã nguồn để mở bằng Android Studio.

## Build APK trên Windows
1. Cài Android Studio và Android SDK.
2. Mở thư mục `LazadaOverlayAssistant` bằng Android Studio.
3. Chờ Gradle Sync hoàn tất.
4. Chọn **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug thường nằm ở `app/build/outputs/apk/debug/app-debug.apk`.


## Tính năng vuốt xuống trên app Lazada gốc

- Trong cửa sổ nổi có nút **Vuốt xuống thử ngay trong Lazada gốc** để kiểm tra thao tác trước.
- Nhập thời gian từ **1 đến 3600 giây** ở mục “Thời gian tự vuốt lại trong Lazada gốc”, bấm “Lưu thời gian tải lại”, sau đó bật/tắt “Bật tự vuốt Lazada gốc”. Chu kỳ mới được đọc ở lượt kế tiếp. Tính năng chỉ chạy khi app `com.lazada.android` đang ở trước màn hình.
- Cần bật dịch vụ Trợ năng của ứng dụng trong Cài đặt Android. Cấu hình dịch vụ yêu cầu khả năng thực hiện cử chỉ.
- Vuốt xuống không phải API làm mới chính thức của Lazada. Nó chỉ làm mới nếu màn hình Lazada hiện tại hỗ trợ kéo xuống để làm mới; nếu không có thể cuộn trang hoặc không có tác dụng. Hãy thử nút vuốt thủ công trước và tắt tự động nếu màn hình cuộn ngoài ý muốn.
- Không nên bật chu kỳ 1 giây lâu dài: có thể hao pin, tốn dữ liệu và làm trang tải không kịp.
- Mã nguồn này chưa được biên dịch/kiểm thử trên thiết bị trong môi trường tạo file.
