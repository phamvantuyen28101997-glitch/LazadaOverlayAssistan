package com.example.lazadaoverlay

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Opens Lazada cart inside this app and reloads the page every 1 second while
 * the activity is visible. This is separate from the Lazada shopping app and
 * may require signing in again in the embedded browser.
 */
class CartActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var autoReload = true
    private var lastLoadAt = 0L

    private val reloadTask = object : Runnable {
        override fun run() {
            if (!autoReload || isFinishing || isDestroyed) return
            status.text = "Tự tải lại: BẬT • mỗi 1 giây"
            // Avoid repeatedly restarting a load that is still in progress.
            if (System.currentTimeMillis() - lastLoadAt >= 1000L) {
                lastLoadAt = System.currentTimeMillis()
                webView.reload()
            }
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CookieManager.getInstance().setAcceptCookie(true)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 8, 12, 8)
        }
        status = TextView(this).apply { text = "Đang mở giỏ hàng Lazada…" }
        controls.addView(status)
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val toggleButton = Button(this).apply { text = "Tạm dừng" }
        toggleButton.setOnClickListener {
            if (autoReload) {
                autoReload = false
                handler.removeCallbacks(reloadTask)
                status.text = "Tự tải lại: TẠM DỪNG"
                toggleButton.text = "Tiếp tục"
            } else {
                autoReload = true
                status.text = "Tự tải lại: BẬT • mỗi 1 giây"
                toggleButton.text = "Tạm dừng"
                handler.removeCallbacks(reloadTask)
                handler.postDelayed(reloadTask, 1000L)
            }
        }
        buttons.addView(toggleButton)
        buttons.addView(Button(this).apply {
            text = "Tải lại ngay"
            setOnClickListener {
                lastLoadAt = System.currentTimeMillis()
                webView.reload()
            }
        })
        controls.addView(buttons)
        root.addView(controls)
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    status.text = if (autoReload) "Giỏ hàng đang mở • tự tải mỗi 1 giây" else "Tự tải lại: TẠM DỪNG"
                }
            }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(webView)
        setContentView(root)
        webView.loadUrl("https://www.lazada.vn/cart/")
    }

    override fun onResume() {
        super.onResume()
        if (autoReload) handler.postDelayed(reloadTask, 1000L)
    }

    override fun onPause() {
        handler.removeCallbacks(reloadTask)
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacks(reloadTask)
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
