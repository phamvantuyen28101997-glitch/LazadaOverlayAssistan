package com.example.lazadaoverlay

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.text.NumberFormat
import java.util.Locale
import org.json.JSONObject
import org.json.JSONArray

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var expanded = true
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel != null) return START_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 10, 12, 12)
            setBackgroundColor(Color.rgb(250, 249, 255))
        }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val head = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(10, 8, 4, 8)
            setBackgroundColor(Color.rgb(83, 61, 207))
        }
        val title = TextView(this).apply {
            text = "💜 Lazada Floating Price\nTheo dõi giá Lazada"
            textSize = 14f; setTextColor(Color.WHITE); setPadding(4, 2, 4, 2)
        }
        head.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(Button(this).apply { text = "—"; setOnClickListener { expanded = !expanded; body.visibility = if (expanded) View.VISIBLE else View.GONE } })
        head.addView(Button(this).apply { text = "×"; setOnClickListener { stopSelf() } })
        root.addView(head)
        val product = EditText(this).apply { hint = "Tên / link sản phẩm Lazada"; textSize = 13f }
        val target = EditText(this).apply { hint = "Giá muốn mua (VND)"; inputType = 2; textSize = 13f }
        val current = EditText(this).apply { hint = "Giá hiện tại (nhập thủ công)"; inputType = 2; textSize = 13f }
        body.addView(TextView(this).apply { text = "SẢN PHẨM & GIÁ MỤC TIÊU"; textSize = 11f; setTextColor(Color.rgb(92, 75, 190)); setPadding(2, 10, 2, 2) })
        body.addView(product); body.addView(target); body.addView(current)
        val savedTargetsTitle = TextView(this).apply { text = "Giá mục tiêu đã lưu"; textSize = 13f; setTextColor(Color.BLACK) }
        savedTargetsTitle.setPadding(2, 10, 2, 4)
        body.addView(savedTargetsTitle)
        val savedTargets = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(savedTargets)
        val status = TextView(this).apply {
            text = "Nhập giá hiện tại để so sánh."; textSize = 12f; setTextColor(Color.rgb(63, 53, 120))
            setPadding(10, 10, 10, 10); setBackgroundColor(Color.rgb(239, 236, 255))
        }
        body.addView(status)
        fun refreshSavedTargets() {
            savedTargets.removeAllViews()
            val prefs = getSharedPreferences("lazada_overlay", MODE_PRIVATE)
            val data = try { JSONObject(prefs.getString("saved_targets_json", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
            if (data.length() == 0) {
                savedTargets.addView(TextView(this).apply { text = "Chưa lưu sản phẩm nào."; textSize = 11f; setTextColor(Color.DKGRAY) })
                return
            }
            val keys = data.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val item = data.optJSONObject(key) ?: continue
                val itemName = item.optString("name", key)
                val itemTarget = item.optLong("target", 0L)
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val load = Button(this).apply {
                    text = "$itemName • ${NumberFormat.getNumberInstance(Locale("vi", "VN")).format(itemTarget)}đ"
                    textSize = 10f
                    setOnClickListener {
                        product.setText(item.optString("product", itemName))
                        target.setText(itemTarget.toString())
                        status.text = "Đã nạp giá mục tiêu đã lưu. Giá hiện tại vẫn cần cập nhật thủ công."
                    }
                }
                row.addView(load, LinearLayout.LayoutParams(0, -2, 1f))
                val delete = Button(this).apply {
                    text = "×"
                    setOnClickListener {
                        data.remove(key)
                        prefs.edit().putString("saved_targets_json", data.toString()).apply()
                        refreshSavedTargets()
                    }
                }
                row.addView(delete)
                savedTargets.addView(row)
            }
        }
        body.addView(Button(this).apply {
            text = "Lưu giá mục tiêu cho sản phẩm"
            setOnClickListener {
                val productValue = product.text.toString().trim()
                val goal = target.text.toString().toLongOrNull()
                if (productValue.isBlank() || goal == null || goal <= 0) {
                    status.text = "Nhập tên hoặc link sản phẩm và giá mục tiêu hợp lệ trước khi lưu."
                } else {
                    val prefs = getSharedPreferences("lazada_overlay", MODE_PRIVATE)
                    val data = try { JSONObject(prefs.getString("saved_targets_json", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
                    val key = productValue.lowercase(Locale.ROOT)
                    data.put(key, JSONObject().put("name", productValue.substringAfterLast("/").ifBlank { productValue }.take(48)).put("product", productValue).put("target", goal))
                    prefs.edit().putString("saved_targets_json", data.toString()).apply()
                    status.text = "Đã lưu giá mục tiêu ${NumberFormat.getNumberInstance(Locale("vi", "VN")).format(goal)}đ cho sản phẩm này."
                    refreshSavedTargets()
                }
            }
        })
        refreshSavedTargets()
        body.addView(Button(this).apply {
            text = "So sánh giá"
            setOnClickListener {
                val goal = target.text.toString().toLongOrNull()
                val now = current.text.toString().toLongOrNull()
                if (goal == null || now == null || goal <= 0 || now <= 0) status.text = "Hãy nhập giá mục tiêu và giá hiện tại hợp lệ."
                else if (now < goal) {
                    status.text = "GIÁ ĐÃ GIẢM THẤP HƠN MỤC TIÊU ${goal - now}đ! Đã gửi thông báo. Hãy kiểm tra giá trên Lazada."
                    sendPriceAlert(product.text.toString().trim(), now, goal, belowTarget = true)
                } else if (now == goal) {
                    status.text = "GIÁ ĐÃ BẰNG MỤC TIÊU! Đã gửi thông báo. Hãy kiểm tra giá trên Lazada."
                    sendPriceAlert(product.text.toString().trim(), now, goal, belowTarget = false)
                } else status.text = "Chưa đạt. Còn cao hơn mục tiêu ${now-goal}đ."
            }
        })
        body.addView(Button(this).apply {
            text = "Giỏ hàng tự tải lại mỗi 1 giây"
            setOnClickListener {
                val cart = Intent(this@OverlayService, CartActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(cart)
            }
        })
        body.addView(Button(this).apply {
            text = "Vuốt xuống thử ngay trong Lazada gốc"
            setOnClickListener {
                val ok = LazadaAccessibilityService.requestOneSwipe()
                Toast.makeText(
                    this@OverlayService,
                    if (ok) "Đã gửi lệnh vuốt. Hãy kiểm tra xem giỏ hàng có làm mới không." else "Hãy bật dịch vụ Trợ năng trước, rồi thử lại.",
                    Toast.LENGTH_LONG
                ).show()
            }
        })
        val prefs = getSharedPreferences("lazada_overlay", MODE_PRIVATE)
        val intervalSeconds = EditText(this).apply {
            hint = "Chu kỳ vuốt xuống (giây, từ 1 đến 3600)"
            inputType = 2
            textSize = 13f
            setText(prefs.getInt("original_app_reload_interval_seconds", 1).toString())
        }
        body.addView(TextView(this).apply {
            text = "Thời gian tự vuốt lại trong Lazada gốc"
            textSize = 12f
            setTextColor(Color.BLACK)
        })
        body.addView(intervalSeconds)
        body.addView(Button(this).apply {
            text = "Lưu thời gian tải lại"
            setOnClickListener {
                val seconds = intervalSeconds.text.toString().toIntOrNull()
                if (seconds == null || seconds !in 1..3600) {
                    status.text = "Nhập thời gian từ 1 đến 3600 giây."
                } else {
                    prefs.edit().putInt("original_app_reload_interval_seconds", seconds).apply()
                    status.text = "Đã lưu chu kỳ vuốt ${seconds} giây. Nếu đang chạy, chu kỳ mới áp dụng ở lượt kế tiếp."
                    Toast.makeText(this@OverlayService, "Đã lưu chu kỳ ${seconds} giây", Toast.LENGTH_SHORT).show()
                }
            }
        })
        val autoReloadButton = Button(this).apply {
            text = if (prefs.getBoolean("original_app_auto_reload", false)) "Tắt tự vuốt Lazada gốc" else "Bật tự vuốt Lazada gốc"
            setOnClickListener {
                val currentlyEnabled = prefs.getBoolean("original_app_auto_reload", false)
                if (currentlyEnabled) {
                    prefs.edit().putBoolean("original_app_auto_reload", false).apply()
                    text = "Bật tự vuốt Lazada gốc"
                    Toast.makeText(this@OverlayService, "Đã tắt tự vuốt Lazada gốc", Toast.LENGTH_SHORT).show()
                } else {
                    val seconds = intervalSeconds.text.toString().toIntOrNull()
                    if (seconds == null || seconds !in 1..3600) {
                        status.text = "Nhập thời gian từ 1 đến 3600 giây rồi lưu trước."
                        return@setOnClickListener
                    }
                    prefs.edit().putInt("original_app_reload_interval_seconds", seconds).putBoolean("original_app_auto_reload", true).apply()
                    text = "Tắt tự vuốt Lazada gốc"
                    Toast.makeText(this@OverlayService, "Hãy bật dịch vụ Trợ năng. Tự vuốt chỉ chạy khi Lazada gốc đang ở trước màn hình.", Toast.LENGTH_LONG).show()
                    val settings = Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                    startActivity(settings)
                }
            }
        }
        body.addView(autoReloadButton)
        body.addView(TextView(this).apply {
            text = "Lưu ý: tự tải lại app gốc dùng thao tác vuốt xuống qua Trợ năng; có thể cuộn trang thay vì làm mới nếu màn hình Lazada không hỗ trợ kéo để làm mới."
            textSize = 10f
            setTextColor(Color.DKGRAY)
        })
        body.addView(Button(this).apply {
            text = "Mở Lazada"
            setOnClickListener {
                val i = packageManager.getLaunchIntentForPackage("com.lazada.android")
                if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i) }
                else { val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.lazada.vn/")); web.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(web) }
            }
        })
        root.addView(body)
        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.88).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 100 }
        // Allow the floating panel to receive taps and keyboard input.
        params.flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        panel = root
        wm.addView(root, params)
        head.setOnTouchListener(object : View.OnTouchListener {
            var sx=0f; var sy=0f; var ox=0; var oy=0
            override fun onTouch(v: View, e: android.view.MotionEvent): Boolean {
                when(e.action) {
                    android.view.MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=params.x; oy=params.y; return true }
                    android.view.MotionEvent.ACTION_MOVE -> { params.x=ox+(e.rawX-sx).toInt(); params.y=oy+(e.rawY-sy).toInt(); wm.updateViewLayout(root,params); return true }
                }; return false
            }
        })
        return START_STICKY
    }
    private fun sendPriceAlert(productText: String, currentPrice: Long, targetPrice: Long, belowTarget: Boolean) {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel("deal", "Cảnh báo giá Lazada", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Thông báo khi giá nhập vào đạt hoặc thấp hơn giá mục tiêu"
                }
            )
        }
        val productName = productText.substringAfterLast("/").ifBlank { productText }.take(60).ifBlank { "Sản phẩm Lazada" }
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, "deal") else Notification.Builder(this)
        builder.setContentTitle("Lazada: giá đã đạt mục tiêu")
            .setContentText("$productName • Giá ${formatVnd(currentPrice)}đ, mục tiêu ${formatVnd(targetPrice)}đ")
            .setStyle(Notification.BigTextStyle().bigText("Sản phẩm: $productName\nGiá hiện tại: ${formatVnd(currentPrice)}đ\nGiá mục tiêu: ${formatVnd(targetPrice)}đ. Mở Lazada để kiểm tra và xác nhận mua."))
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setAutoCancel(true)
        if (productText.startsWith("http://") || productText.startsWith("https://")) {
            val openProduct = PendingIntent.getActivity(
                this, productText.hashCode(), Intent(Intent.ACTION_VIEW, Uri.parse(productText)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.setContentIntent(openProduct)
        }
        manager.notify(productText.ifBlank { "default" }.hashCode(), builder.build())
    }

    private fun formatVnd(value: Long): String = NumberFormat.getNumberInstance(Locale("vi", "VN")).format(value)

    override fun onDestroy() { if (panel != null) { wm.removeView(panel); panel=null }; super.onDestroy() }
}
