package com.example.lazadaoverlay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.content.pm.PackageManager
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(79, 58, 210)
        window.navigationBarColor = Color.WHITE
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 28)
            setBackgroundColor(Color.rgb(246, 247, 255))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 24)
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.rgb(79, 58, 210), Color.rgb(112, 73, 230))).apply { cornerRadius = 28f }
        }
        header.addView(TextView(this).apply {
            text = "💜 Lazada Floating Price"; textSize = 23f; setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
        })
        header.addView(TextView(this).apply {
            text = "Theo dõi giá • Cảnh báo mục tiêu • Vuốt bằng Trợ năng"
            textSize = 14f; setTextColor(Color.rgb(238, 234, 255)); setPadding(0, 10, 0, 0)
        })
        box.addView(header)
        box.addView(TextView(this).apply {
            text = "BẮT ĐẦU"; textSize = 13f; setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(92, 75, 190)); setPadding(4, 24, 4, 8)
        })
        fun addAction(label: String, action: () -> Unit) {
            val button = Button(this).apply {
                text = label; textSize = 14f; isAllCaps = false
                setTextColor(Color.rgb(64, 48, 160))
                background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = 20f; setStroke(1, Color.rgb(225, 221, 255)) }
                setPadding(12, 12, 12, 12)
                setOnClickListener { action() }
            }
            box.addView(button, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        }
        addAction("1. Cho phép hiển thị trên ứng dụng khác") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        addAction("2. Bật cửa sổ nổi") {
            if (Settings.canDrawOverlays(this@MainActivity)) {
                startService(Intent(this@MainActivity, OverlayService::class.java))
                Toast.makeText(this@MainActivity, "Đã bật cửa sổ nổi", Toast.LENGTH_SHORT).show()
            } else Toast.makeText(this@MainActivity, "Hãy cấp quyền ở bước 1 trước", Toast.LENGTH_LONG).show()
        }
        addAction("3. Mở Lazada gốc") {
            val i = packageManager.getLaunchIntentForPackage("com.lazada.android")
            if (i != null) startActivity(i) else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.lazada.vn/")))
        }
        box.addView(TextView(this).apply {
            text = "Tính năng: lưu giá mục tiêu từng sản phẩm, so sánh giá thủ công, cảnh báo khi giá đạt mục tiêu và tùy chỉnh chu kỳ vuốt 1–3.600 giây."
            textSize = 13f; setTextColor(Color.DKGRAY); setPadding(6, 12, 6, 8)
        })
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.rgb(246, 247, 255)); addView(box) })
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 2001)
        }
    }
}
