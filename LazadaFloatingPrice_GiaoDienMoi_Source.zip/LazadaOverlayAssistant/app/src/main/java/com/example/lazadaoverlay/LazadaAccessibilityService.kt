package com.example.lazadaoverlay

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/**
 * Best-effort automation for the ORIGINAL Lazada app.
 * Pull-to-refresh only works if the current Lazada screen supports it and the
 * content is already at the top. It may scroll the page instead of refreshing.
 */
class LazadaAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile private var activeService: LazadaAccessibilityService? = null
        fun requestOneSwipe(): Boolean {
            val service = activeService ?: return false
            service.handler.post { service.performPullDownGesture() }
            return true
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var lazadaForeground = false
    private var gestureInFlight = false

    private val refreshTask = object : Runnable {
        override fun run() {
            if (!isEnabledByUser() || !lazadaForeground) return
            if (!gestureInFlight) performPullDownGesture()
            // Read the user-configured interval each cycle (1–3600 seconds).
            handler.postDelayed(this, reloadIntervalMs())
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val packageName = event?.packageName?.toString() ?: return
        val nowLazada = packageName == "com.lazada.android"
        if (nowLazada != lazadaForeground) {
            lazadaForeground = nowLazada
            handler.removeCallbacks(refreshTask)
            if (lazadaForeground && isEnabledByUser()) handler.postDelayed(refreshTask, reloadIntervalMs())
        }
        // Some Android/Lazada builds emit content events without a window-state change.
        if (lazadaForeground && isEnabledByUser()) {
            if (!handler.hasCallbacks(refreshTask) && !gestureInFlight) {
                handler.postDelayed(refreshTask, reloadIntervalMs())
            }
        }
    }

    override fun onInterrupt() {
        handler.removeCallbacks(refreshTask)
        gestureInFlight = false
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        activeService = this
        lazadaForeground = rootInActiveWindow?.packageName?.toString() == "com.lazada.android"
        if (lazadaForeground && isEnabledByUser()) handler.postDelayed(refreshTask, reloadIntervalMs())
    }

    override fun onDestroy() {
        handler.removeCallbacks(refreshTask)
        if (activeService === this) activeService = null
        super.onDestroy()
    }

    private fun isEnabledByUser(): Boolean =
        getSharedPreferences("lazada_overlay", MODE_PRIVATE).getBoolean("original_app_auto_reload", false)

    private fun reloadIntervalMs(): Long {
        val seconds = getSharedPreferences("lazada_overlay", MODE_PRIVATE)
            .getInt("original_app_reload_interval_seconds", 1).coerceIn(1, 3600)
        return seconds * 1000L
    }

    fun performPullDownGesture() {
        if (gestureInFlight) return
        val metrics = resources.displayMetrics
        val x = metrics.widthPixels * 0.5f
        val startY = metrics.heightPixels * 0.22f
        val endY = metrics.heightPixels * 0.62f
        val path = Path().apply {
            moveTo(x, startY)
            lineTo(x, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 350)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        gestureInFlight = true
        val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                gestureInFlight = false
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                gestureInFlight = false
            }
        }, null)
        if (!accepted) gestureInFlight = false
    }
}
